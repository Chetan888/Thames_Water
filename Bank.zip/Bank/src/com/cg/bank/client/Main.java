package com.cg.bank.client;
import com.cg.bank.customer.Account;
import com.cg.bank.customer.Customer;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;
import com.cg.bank.daoservices.CustomerDao;
import com.cg.bank.daoservices.CustomerDaoImpl;
import com.cg.bank.services.BankService;
import com.cg.bank.services.BankServicesImpl;
import com.cg.bank.util.BankUtil;
public class Main {
	public static void main(String[] args) {
		try {
		CustomerDao cd=new CustomerDaoImpl();
			BankService bankService=new BankServicesImpl();
			int customerID=bankService.acceptCustomerDetails(101, 564125, 584121, 4356, "pradnys", "shinde", "ps@gmail.com", "fh4", "pune", "mh", "INDIA", 5451, 0, "saving");
			System.out.println("customer id is:"+customerID);
			Customer customer=bankService.getCustomerDetails(customerID);
			System.out.println(customer.toString());						
			int depositValue=bankService.deposit(5000, customerID);
			System.out.println("deposit amount:"+depositValue);
			int withdrawValue=bankService.withDraw(3000, customerID);
			System.out.println("withdra amount:"+withdrawValue);
			int depositValue1=bankService.deposit(5000, customerID);
			int withdrawValue1=bankService.withDraw(3000, customerID);
			System.out.println("withdra amount:"+withdrawValue1);
			Customer c=cd.findOne(customerID);
			System.out.println("orignal account balance is "+c.getAccount().getAccountBalance());
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}