package com.cg.bank.customer;
public class Transaction {
private int transacrionID,timeTamp,amount;
private String transactionType,transactionLocation,modeofTransaction,transactionStatus;
public Transaction() {
}


public Transaction(int amount) {
	super();
	this.amount = amount;
}


public Transaction(int transacrionID, int timeTamp, int amount, String transactionType, String transactionLocation,
		String modeofTransaction, String transactionStatus) {
	super();
	this.transacrionID = transacrionID;
	this.timeTamp = timeTamp;
	this.amount = amount;
	this.transactionType = transactionType;
	this.transactionLocation = transactionLocation;
	this.modeofTransaction = modeofTransaction;
	this.transactionStatus = transactionStatus;
}
public int getTransacrionID() {
	return transacrionID;
}
public void setTransacrionID(int transacrionID) {
	this.transacrionID = transacrionID;
}
public int getTimeTamp() {
	return timeTamp;
}
public void setTimeTamp(int timeTamp) {
	this.timeTamp = timeTamp;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public String getTransactionLocation() {
	return transactionLocation;
}
public void setTransactionLocation(String transactionLocation) {
	this.transactionLocation = transactionLocation;
}
public String getModeofTransaction() {
	return modeofTransaction;
}
public void setModeofTransaction(String modeofTransaction) {
	this.modeofTransaction = modeofTransaction;
}
public String getTransactionStatus() {
	return transactionStatus;
}
public void setTransactionStatus(String transactionStatus) {
	this.transactionStatus = transactionStatus;
}


@Override
public String toString() {
	return "Transaction [transacrionID=" + transacrionID + ", timeTamp=" + timeTamp + ", amount=" + amount
			+ ", transactionType=" + transactionType + ", transactionLocation=" + transactionLocation
			+ ", modeofTransaction=" + modeofTransaction + ", transactionStatus=" + transactionStatus + "]";
}

}
