package com.cg.bank.customer;
public class Customer {
	private int customerID,mobileNo,aadharNo,dofBirth;
	private String firstName,lastName,emailID,panID;
	//Account [] accounts=new Account[5];
	
	private Transaction transaction;
	//Address address;
	Account account=new Account();
	Transaction transaction2=new Transaction();
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int mobileNo, int aadharNo, int dofBirth, String firstName, String lastName, String emailID,
			String panID, Account account) {
		super();
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
		this.dofBirth = dofBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.panID = panID;
		this.account = account;
	
	}
	public Customer(int customerID, int mobileNo, int aadharNo, int dofBirth, String firstName, String lastName,
			String emailID, String panID, Account account) {
		super();
		this.customerID = customerID;
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
		this.dofBirth = dofBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.panID = panID;
		this.account = account;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}
	public int getDofBirth() {
		return dofBirth;
	}
	public void setDofBirth(int dofBirth) {
		this.dofBirth = dofBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPanID() {
		return panID;
	}
	public void setPanID(String panID) {
		this.panID = panID;
	}


	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
	
}

