package com.cg.dto;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.cg.util.MyStringDateUtil;

@Entity
@Table(name="reg_details")
public class RegisterDto {
	
	@Column(name="user_skills", length=10)
	private String skillSetStr;
	
	
	public String getSkillSetStr() {
		return skillSetStr;
	}

	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}

	//@NotEmpty(message="Username is Mandatory")
	@Id
	@Column(name="user_name", length=25)
	private String uname;
	
	@Transient
	@NotEmpty(message="Password is Mandatory")
	private String password;
	
	@Transient
	@NotEmpty(message="Confirm Password is Mandatory")
	private String confPass;
	
	@Column(name="first_name",length=25)
	@NotEmpty(message="First Name is Mandatory")
	@Pattern(regexp="[A-Z][a-z]*")
	private String fname;
	
	@Column(name="last_name",length=25)
	@NotEmpty(message="Last Name is Mandatory")
	@Pattern(regexp="[A-Z][a-z]*")
	private String lname;
	
	@NotEmpty()
	@Column(name="user_email",length=30)
	//@Pattern(regexp="[A-Z][a-z]*" ,message="Email is Mandatory")
	private String emailId;
	
	@Transient
	private String[] skillSet;
	
	@Column(name="user_gender",length=10)
	private char gender;
	
	@Column(name="user_city",length=13)
	private String city;
	
	public RegisterDto(){}

	public String getUname() {
		return uname;
	}

	@Override
	public String toString() {
		return "RegisterDto [uname=" + uname + ", password=" + password + ", confPass=" + confPass + ", fname=" + fname
				+ ", lname=" + lname + ", emailId=" + emailId + ", skillSet=" + Arrays.toString(skillSet) + ", gender="
				+ gender + ", city=" + city + "]";
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfPass() {
		return confPass;
	}

	public void setConfPass(String confPass) {
		this.confPass = confPass;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String[] getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
		setSkillSetStr(MyStringDateUtil.fromArrayToCommaSeparatedString(skillSet));
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
