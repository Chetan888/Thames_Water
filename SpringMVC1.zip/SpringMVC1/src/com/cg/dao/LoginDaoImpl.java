package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;
	
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	//******************* Insert Registration Data******************************//
	
	
	public RegisterDto insertUserDetails(RegisterDto userData)
	{
		
		Login logobj = new Login();
		
		logobj.setUserName(userData.getUname());
		logobj.setPassWord(userData.getPassword());
		
		entityManager.persist(userData);
		entityManager.persist(logobj);
		//entityManager.flush();
		
		RegisterDto rd = entityManager.find(RegisterDto.class, userData.getUname());
		return rd;
		
	}
	
	@Override
	public boolean isUserExist(String user) {
		
		Login usr = entityManager.find(Login.class, user);
		if(usr!=null)
			return true;
		else
		return false;
	}

	@Override
	public Login validateUser(Login login) {
		
		Login usr = entityManager.find(Login.class, login);
		return usr;
	}

	
	@RequestMapping(value="/deleteuser",method=RequestMethod.GET)
	public RegisterDto deleteUser(String usn)
	{
		
		RegisterDto rdto = entityManager.find(RegisterDto.class,usn);
		Login logindto = entityManager.find(Login.class,usn);
		
		entityManager.remove(rdto);
		entityManager.remove(logindto);
		entityManager.flush();
		return rdto;
	}
}
