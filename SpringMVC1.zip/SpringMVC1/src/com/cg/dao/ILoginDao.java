package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;

public interface ILoginDao {

	
		public RegisterDto insertUserDetails(RegisterDto userData);
		public boolean isUserExist(String user);
		public Login validateUser(Login login);
		
		public RegisterDto deleteUser(String usn);
		//public String 
		
	
}
