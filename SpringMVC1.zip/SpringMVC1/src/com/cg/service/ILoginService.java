package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;

public interface ILoginService {
	
	public boolean isUserExist(String user);
	public Login validateUser(Login login);
	public RegisterDto insertUserDetails(RegisterDto userData);
	public RegisterDto deleteUser(String usn);
	public ArrayList<RegisterDto> getAllUserDetails();	
}
