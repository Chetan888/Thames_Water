package com.cg.service;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.RegisterDto;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	EntityManager entityManager=null;
	@Autowired()
	ILoginDao dao = null;

	public ILoginDao getDao() {
		return dao;
	}

	public void setDao(ILoginDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean isUserExist(String user) {
		return dao.isUserExist(user);
	}

	//******************* Insert Registration Data******************************//
	
	
	public RegisterDto insertUserDetails(RegisterDto userData)
	{
			
			return dao.insertUserDetails(userData);
			
	}
		
	@Override
	public Login validateUser(Login log) {

		Login dbUser = dao.validateUser(log);
		if(log.getUserName().equalsIgnoreCase(dbUser.getUserName()) && 
				log.getPassWord().equalsIgnoreCase(dbUser.getPassWord()))
			return dbUser;
		else
			return null;
		
	}

	@Override
	public RegisterDto deleteUser(String usn) {
		return dao.deleteUser(usn);
	}

public ArrayList<RegisterDto> getAllUserDetails(){
	// TODO Auto-generated method stub
    
	String qry="SELECT reg FROM RegisterDto reg"; 
    TypedQuery tq = entityManager.createQuery(qry,RegisterDto.class);
     ArrayList<RegisterDto> uList = (ArrayList<RegisterDto>) tq.getResultList();
    return uList;	
	
	}
	
	

}
