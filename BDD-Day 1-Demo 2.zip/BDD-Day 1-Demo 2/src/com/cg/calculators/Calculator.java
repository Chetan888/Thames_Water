package com.cg.calculators;

public class Calculator {
	
	
	public static void main(String []args)
	{
		Calculator c = new Calculator();
		System.out.println("Addition is "+c.Add(43, 55));
		System.out.println("Substraction is "+c.Sub(767, 5));
		System.out.println("Multiplication is "+c.Mul(45, 754));
		System.out.println("Division is "+c.Div(6545, 5));
		
	}
	
	public int Add(int a,int b)
	{
		return a+b;
	}
	public int Sub(int a,int b)
	{
		return a-b;
	}
	public int Div(int a,int b)
	{
		return a/b;
	}
	public int Mul(int a,int b)
	{
		return a*b;
	}

}
