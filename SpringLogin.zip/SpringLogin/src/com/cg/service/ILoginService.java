package com.cg.service;
import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
public interface ILoginService {
	public boolean isUserExist(String userName);
	public Login validateUser(Login login);
	public RegisterDto insertUserDetials(RegisterDto userDetails);
}
