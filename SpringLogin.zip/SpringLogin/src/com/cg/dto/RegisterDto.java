package com.cg.dto;
import java.util.Arrays;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="cg_userdetails")
public class RegisterDto {
	@NotEmpty(message="User name mandatory")
	@Id
	@Column(name="user_name",length=25)
    private String uname;
	@Transient
    private String password;
	@Transient
    private String confPass;
    @Pattern(regexp="[A-Z][a-z]*",message="First name is not Valid")
    @Column(name="firstName",length=20)
    private String fname;
    @Column(name="last_name",length=30)
    private String lname;
    @NotEmpty(message="Email is mandatory")
    @Email(message="email is mandatory")
    @Column(name="user_email",length=20)
    private String emailId;
    @Transient
    private String[] skillSet;
    @Column(name="user_skills",length=75)
    private String skillSetStr;
    @Column(name="gender")
    private char gender;
    @Column(name="user_city",length=15)
    private String city;
    
    public RegisterDto(){}
    public String getUname() {
        return uname;
    }
    @Override
    public String toString() {
        return "RegisterDto [uname=" + uname + ", password=" + password + ", confPass=" + confPass + ", fname=" + fname
                + ", lname=" + lname + ", emailId=" + emailId + ", skillSet=" + Arrays.toString(skillSet) + ", gender="
                + gender + ", city=" + city + "]";
    }
    public void setUname(String uname) {
        this.uname = uname;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getConfPass() {
        return confPass;
    }
    public void setConfPass(String confPass) {
        this.confPass = confPass;
    }
    public String getFname() {
        return fname;
    }
    public void setFname(String fname) {
        this.fname = fname;
    }
    public String getLname() {
        return lname;
    }
    public void setLname(String lname) {
        this.lname = lname;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String[] getSkillSet() {
        return skillSet;
    }
    public void setSkillSet(String[] skillSet) {
        this.skillSet = skillSet;
        setSkillSetStr(skillSet.toString());
    }
    public String getSkillSetStr() {
		return skillSetStr;
	}
	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}
	public char getGender() {
        return gender;
    }
    public void setGender(char gender) {
        this.gender = gender;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
}
