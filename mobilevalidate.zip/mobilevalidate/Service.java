package com.cg.mobilevalidate;

import java.util.List;
import java.util.regex.Pattern;

public class Service {

	public String validateMobileNumber(List<String> list) {
		// TODO Auto-generated method stub
		boolean flag=true;
		String message;
		String regex = "^[0-9] {10}$";
		for(String mobno: list)
		{
			if(Pattern.matches(regex, mobno))
				continue;
			flag=true;
			
		}
		if(!flag)
			message="Invalid Mobile Number is Present in DataSet";
		else
			message="all Mobile Numbers are Valid in DataSet";
		return message;
	}

}
