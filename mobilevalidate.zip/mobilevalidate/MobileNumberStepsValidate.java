package com.cg.mobilevalidate;

import static org.testng.Assert.assertEquals;
import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MobileNumberStepsValidate {
	

	Service service;
	String message;
	
	@Given("^user Creates Calculator object and call  add method$")
	public void user_Creates_Calculator_object_and_call_add_method() 
	{
	
				service = new Service(); 
		
		
	}

	@When("^user will pass valid input$")
	public void user_will_pass_valid_input(DataTable data) 
	{
			
			List<String> list = data.asList(String.class);
			message=service.validateMobileNumber(list);		

	}

	@Then("^add method should return Result\\.$")
	public void add_method_should_return_Result() throws Throwable {
			
				assertEquals(message, "Invalid Numbers are Present in DataSet");

	}

	@Given("^user cretaes calculator object and call add method$")
	public void user_cretaes_calculator_object_and_call_add_method() 
{


	}

	@When("^user gives one valid and one invalid input$")
	public void user_gives_one_valid_and_one_invalid_input() 
 {


	}

	@Then("^add method should throw Exception$")
	public void add_method_should_throw_Exception()
 {


	}

	@When("^use given valid (\\d+) to findSquare\\(\\)$")
	public void use_given_valid_to_findSquare(int arg1) 
 {

 }

	@Then("^method should return correct Square$")
	public void method_should_return_correct_Square()  {
	   
	}



}
