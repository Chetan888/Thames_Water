package com.cg.calculators;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddNumberStepDefs {


@Given("^user Creates Calculator object and call  add method$")
public void user_Creates_Calculator_object_and_call_add_method() throws Throwable {
 
	
	
	
	
    throw new PendingException();
}

@When("^user will pass valid input$")
public void user_will_pass_valid_input() throws Throwable {
   
	
	
	
	
	
    throw new PendingException();
}

@Then("^add method should return Result\\.$")
public void add_method_should_return_Result() throws Throwable {
    
	
	
	
	
    throw new PendingException();
}

@Given("^user cretaes calculator object and call add method$")
public void user_cretaes_calculator_object_and_call_add_method() throws Throwable {


	
	
    throw new PendingException();
}

@When("^user gives one valid and one invalid input$")
public void user_gives_one_valid_and_one_invalid_input() throws Throwable {
 

	
    throw new PendingException();
}

@Then("^add method should throw Exception$")
public void add_method_should_throw_Exception() throws Throwable {
    
	
	
	
	
	
    throw new PendingException();
}


	
}
