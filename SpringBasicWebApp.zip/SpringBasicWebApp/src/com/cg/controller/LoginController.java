package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
import com.cg.service.ILoginService;

@Controller
public class LoginController {
	ArrayList<String> cityList=null;
	ArrayList<String> skillSet=null;
	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}

	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login lg=new Login();
		lg.setUserName("Enter ur userName here");
		model.addAttribute("log", lg);
		model.addAttribute("compNameObj", "Capgemini");
		return "Login";
	}
	
	/************************Validate User*******************/
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log") 
			@Valid Login lg, BindingResult result,Model model) {
		if(result.hasErrors()) {
			return "Login";
		}else {
			if(logSer.isUserExist(lg.getUserName())) {
			Login user=logSer.validateUser(lg);
			if(user!=null){
					model.addAttribute("unmObj",lg.getUserName());
					return "Success";
				}else {
					return "Failure";
				}
			}else {
				return  "redirect:/ShowRegisterPage.obj";
			}
		}
	}
	
	/************************Register User*******************/
	@RequestMapping(value="/ShowRegisterPage", method=RequestMethod.GET)
	public String displayRegPage(Model model) {
		 cityList=new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Nagpur");
		cityList.add("G.Noida");
		cityList.add("Varanasi");
		
		skillSet=new ArrayList<String>();
		skillSet.add("JAVA");
		skillSet.add(".NET");
		skillSet.add("Oracle");
		skillSet.add("HTML");
		skillSet.add("NODE.JS");
		
		RegisterDto rd= new RegisterDto(); 
		model.addAttribute("reg", rd);
		model.addAttribute("cList", cityList);
		model.addAttribute("skillList", skillSet);
		return "Register";
	}
	/************************InsertUser.obj*******************/
	@RequestMapping(value="/InsertUser", method=RequestMethod.POST)
	public String addUserDeatils(@ModelAttribute(value="reg")
			@Valid RegisterDto rd, BindingResult result, Model model) {
		if(result.hasErrors()) {
			model.addAttribute("cList", cityList);
			model.addAttribute("skillList", skillSet);
			return "Register";
			
		}else {
			RegisterDto rdd=logSer.insertuserDetails(rd);
					ArrayList<RegisterDto> userList= logSer.getAllUserDetails();
					model.addAttribute("userListObj", userList);
					return "ListAllUser";
		}
	}
	
	/************************deleteUser.obj*******************/
	@RequestMapping(value="/deleteUser", method=RequestMethod.GET)
	public String deleteUser(@RequestParam(value="uid")
			String unm, Model model) {
		
		RegisterDto rd=logSer.deleteUsers(unm);
		
		if(rd!=null) {
			ArrayList<RegisterDto> userList= logSer.getAllUserDetails();
			model.addAttribute("userListObj", userList);
			model.addAttribute("MsgObj", "Data deleted");
			return "ListAllUser";
		}else {
			return "Error";
		}
	}
}