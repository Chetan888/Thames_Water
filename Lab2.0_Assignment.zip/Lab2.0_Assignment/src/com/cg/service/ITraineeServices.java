package com.cg.service;

import com.cg.dto.Trainee;

public interface ITraineeServices {
    Trainee insertTrainee(Trainee trainee);

    Trainee deleteTrainee(String traineeId);
    
    Trainee updateTrainee(int traineeId);

	Trainee searchTrainee(String traineeId);
}