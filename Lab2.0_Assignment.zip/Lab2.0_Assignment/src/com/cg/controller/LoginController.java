package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;

import com.cg.dto.Trainee;
import com.cg.service.ITraineeServices;

@Controller
public class LoginController {
	ArrayList<String> traineeDomain=null;
	ArrayList<String>traineeLocation=null;
	@Autowired
	ITraineeServices trnSer=null;
	public ITraineeServices getTrnSer() {
		return trnSer;
	}


	public void setTrnSer(ITraineeServices trnSer) {
		this.trnSer = trnSer;
	}


	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login lg=new Login();
		model.addAttribute("log", lg);
		return "Login";
	}
	
	
	/************************Validate User*******************/
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log") 
			@Valid Login lg, BindingResult result,Model model) {
		if (lg.getUserName().equalsIgnoreCase("admin") && lg.getPassword().equalsIgnoreCase("admin"))
            return "Menu";
        return "Login";
	}
	
	/************************Add Trainee*******************/
	@RequestMapping(value="/AddTrainee", method=RequestMethod.GET)
	public String addTraineePage(Model model) {
		traineeDomain=new ArrayList<String>();
		traineeDomain.add("JEE");
		traineeDomain.add("CRM");
		traineeDomain.add("Python");
		traineeDomain.add(".Net");
		
		traineeLocation=new ArrayList<String>();
		traineeLocation.add("Chennai");
		traineeLocation.add("Banglore");
		traineeLocation.add("Pune");
		traineeLocation.add("Mumbai");
		
		Trainee tr= new Trainee(); 
		model.addAttribute("trn", tr);
		model.addAttribute("tDomain", traineeDomain);
		model.addAttribute("tLoc", traineeLocation);
		return "AddTrainee";
	}
	/************************InsertTrainee.obj*******************/
	@RequestMapping(value = "/InsertTrainee", method = RequestMethod.POST)
    public String insertTraineeDetails(@ModelAttribute(value = "trn") Trainee trainee, Model model) {
        if (trnSer.insertTrainee(trainee) != null) {
            model.addAttribute("msg", "Trainee added successfully");
            return  "redirect:/AddTrainee.obj";
        } else {
            model.addAttribute("msg", "Failed to add trainee");
            return  "redirect:/AddTrainee.obj";
        }
    }
	
	
	/************************deleteTrainee.obj*******************/
	@RequestMapping(value="/DeleteTrainee", method=RequestMethod.GET)
	public String deleteUser( Model model) {
		Trainee tr= new Trainee(); 
		model.addAttribute("trn", tr);	
				return "DeleteTraineePage";
		
		
	}
	 @RequestMapping(value="/deleteUser",method=RequestMethod.POST)
	    public String deleteUser(@ModelAttribute(value="trn") Trainee trainee,Model model) {
	        Trainee tr=trnSer.deleteTrainee(trainee.getTraineeId());
	            return "DeleteTraineePage";
	       
	    }
	/*********************Display Trainee Details**************************/
	 @RequestMapping(value = "/DisplayTraineePage", method = RequestMethod.GET)
		public String displayTraineePage(Model model) {
		 Trainee tr= new Trainee(); 
			model.addAttribute("trn", tr);	
			return "DisplayTrainee";
		}

		@RequestMapping(value="DisplayTrainee")
		public String displayTrainee(@ModelAttribute(value="trn")Trainee trainee, Model model) {
			trainee=trnSer.searchTrainee(trainee.getTraineeId());
			if((trainee)!= null) {
				model.addAttribute("trainee", trainee);
				model.addAttribute("htmlCode", "<table border=\"3\" style=\"width: 30%\"><tr><th>Name</th><th>ID</th><th>Domain</th><th>Location</th></tr><tr><td>"
				+trainee.getTraineeName()+"</td><td>"+ trainee.getTraineeId()+"</td><td>"
				+trainee.getTraineeDomain()+"</td><td>"+trainee.getTraineeLocationStr()
				+"</td></tr></table>");
				return "DisplayTrainee";
			}
			return null;
		}
	
}