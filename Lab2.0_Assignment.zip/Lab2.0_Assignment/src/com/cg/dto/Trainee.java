package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cg.util.MyStringDateUtil;

@Entity
@Table(name="cg_traineedetails")
public class Trainee {
	@Id
	@Column(name="trainee_id", length=250)
	private String traineeId;
	@Column(name="tainee_name", length=100)
	private String traineeName;
	@Column(name="trainee_domain", length=100)
	private String traineeDomain;
	@Transient
	private String[] traineeLocation;
	@Column(name="trainee_location", length=100)
	private String traineeLocationStr;
	
	public String getTraineeLocationStr() {
		return traineeLocationStr;
	}
	public void setTraineeLocationStr(String traineeLocationStr) {
		this.traineeLocationStr = traineeLocationStr;
	}
	public String getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(String traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String taineeName) {
		this.traineeName = taineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String[] getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String[] traineeLocation) {
		this.traineeLocation = traineeLocation;
		String location=MyStringDateUtil.fromArrayToCommaSeparatedString(traineeLocation);
		setTraineeLocationStr(location);
	}
}
