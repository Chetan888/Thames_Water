package com.cg.dao;

import com.cg.dto.Login;

public interface ILoginDao {

	

		public boolean isUserExist(String user);
		public Login validateUser(Login login);
		
	
}
