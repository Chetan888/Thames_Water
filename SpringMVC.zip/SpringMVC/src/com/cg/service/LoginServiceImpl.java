package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Autowired()
	ILoginDao dao = null;

	public ILoginDao getDao() {
		return dao;
	}

	public void setDao(ILoginDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean isUserExist(String user) {






		return false;
	}

	@Override
	public Login validateUser(Login log) {

		if(log.getUserName().equalsIgnoreCase("11111") && 
				log.getPassWord().equalsIgnoreCase("11111"))
		{
			return log;
		}
		else
		{
			
			return null;
		}
		
	}

}
