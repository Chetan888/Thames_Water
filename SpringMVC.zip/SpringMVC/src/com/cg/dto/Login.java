package com.cg.dto;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Login {
	
	
	
	private String userName;
	
	
	private String passWord;
	
	public Login() {}
	@NotEmpty(message="Username is required")
	@Size(min=5,message="min 5 characters are required")
	
	
	
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	@NotEmpty(message="Password is required")
	public String getPassWord() {
		return passWord;
	}
	
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	
	
}
